<?php
/*
Plugin Name: TW Dev
Plugin URI: 
Description: Customization by TheTailoredWebsite
Version: 1.0
Author: Alvaro Lobato
Author URI: 
*/

if ( !defined('ABSPATH') ) {
	die;
} // Cannot access pages directly.

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

include_once(ABSPATH . 'wp-admin/includes/plugin.php');

if (is_plugin_active('woocommerce/woocommerce.php')) {
	function appsero_init_tracker_mage_eventpress()
	{
		if (!class_exists('Appsero\Client')) {
			require_once __DIR__ . '/lib/appsero/src/Client.php';
		}
		$client = new Appsero\Client('08cd627c-4ed9-49cf-a9b5-1536ec384a5a', 'WooCommerce Event Manager', __FILE__);
		$client->insights()->init();
	}

	function mep_event_activation_redirect($plugin)
	{
		if ($plugin == plugin_basename(__FILE__)) {
			exit(wp_redirect(admin_url('edit.php?post_type=mep_events&page=mep_event_welcome_page')));
		}
	}
	add_action('activated_plugin', 'mep_event_activation_redirect');
	require_once(dirname(__FILE__) . "/inc/mep_file_include.php");
} else {
	function mep_admin_notice_wc_not_active()
	{
		$class = 'notice notice-error';
		printf(
			'<div class="error" style="background:red; color:#fff;"><p>%s</p></div>',
			__('You Must Install WooCommerce Plugin before activating WooCommerce Event Manager, Becuase It is dependent on Woocommerce Plugin')
		);
	}
	add_action('admin_notices', 'mep_admin_notice_wc_not_active');
}

class CocCalculatorPlugin {
	private function is_bot() {
		if (!isset($_SERVER['HTTP_USER_AGENT']))
			return false;

		$crawlers_agents = strtolower('Bloglines subscriber|Dumbot|Sosoimagespider|QihooBot|FAST-WebCrawler|Superdownloads Spiderman|LinkWalker|msnbot|ASPSeek|WebAlta Crawler|Lycos|FeedFetcher-Google|Yahoo|YoudaoBot|AdsBot-Google|Googlebot|Scooter|Gigabot|Charlotte|eStyle|AcioRobot|GeonaBot|msnbot-media|Baidu|CocoCrawler|Google|Charlotte t|Yahoo! Slurp China|Sogou web spider|YodaoBot|MSRBOT|AbachoBOT|Sogou head spider|AltaVista|IDBot|Sosospider|Yahoo! Slurp|Java VM|DotBot|LiteFinder|Yeti|Rambler|Scrubby|Baiduspider|accoona');
	    $crawlers = explode("|", $crawlers_agents);
        foreach($crawlers as $crawler) {
            if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), trim($crawler)) !== false) {
                return true;
            }
	    }
	    return false;
	}

	public function __construct() {
		if (!$this->is_bot()) {
			add_action('wp_enqueue_scripts', array($this, 'enqueue'), 15);
		}
	}

	public function enqueue() {
        wp_enqueue_style( 'plugin_styles', plugin_dir_url(__FILE__).'css/plugin_styles.css', array(), '2.0', 'all' );
        wp_enqueue_script('jquery_inputmask',  plugin_dir_url(__FILE__).'js/jquery.inputmask.js', array('jquery'), '2.0', true);
        wp_enqueue_script('plugin_js',  plugin_dir_url(__FILE__).'js/plugin_js.js', array(), '2.0', true);
        
	}

	public function processShortcode($attrs) {
		$avgsalmgr = empty($attrs['avgsalmgr']) ? '0' : $attrs['avgsalmgr'];
        $avgsalstf = empty($attrs['avgsalstf']) ? '0' : $attrs['avgsalstf'];
        $avgwhwmgr = empty($attrs['avgwhwmgr']) ? '0' : $attrs['avgwhwmgr'];
        $avgwhwstf = empty($attrs['avgwhwstf']) ? '0' : $attrs['avgwhwstf'];
        $avgcmhmgr = empty($attrs['avgcmhmgr']) ? '0' : $attrs['avgcmhmgr'];
        $avgcmhstf = empty($attrs['avgcmhstf']) ? '0' : $attrs['avgcmhstf'];
        $noemgr = empty($attrs['noemgr']) ? '0' : $attrs['noemgr'];
        $noestf = empty($attrs['noestf']) ? '0' : $attrs['noestf'];
        $reslpymgr = empty($attrs['reslpymgr']) ? '£' : $attrs['reslpymgr'];
        $reslpystf = empty($attrs['reslpystf']) ? '£' : $attrs['reslpystf'];
        $resgtolpy = empty($attrs['resgtolpy']) ? '£' : $attrs['resgtolpy'];

		$out = <<<HEREDOC
        <form name='cocForm' class='cedr-calculator'>
        <table width='100%' class='calctable' cellspacing='7'>
            <tr class='header'><td></td><td>Manager</td><td>Staff</td></tr>
            
            <tr class='grey'><td>Average salary cost (incl. tax and bonus)</td>
            <td><input type='text' name='avgsalmgr' class='inputmask' value='<?php echo $avgsalmgr ?>' placeholder='£'/></td>
            <td><input type='text' name='avgsalstf' class='inputmask' value='<?php echo $avgsalstf ?>' placeholder='£'/></td></tr>
            <tr class='white'><td>Average work hours / week</td>
            <td><input type='number' name='avgwhwmgr' value='<?php echo $avgwhwmgr ?>' placeholder='0'/></td>
            <td><input type='number' name='avgwhwstf' value='<?php echo $avgwhwstf ?>' placeholder='0'//></td></tr>
            <tr class='grey'><td>Average h. / week spent on managing conflict (*)</td>
            <td><input type='number' name='avgcmhmgr' value='<?php echo $avgcmhmgr ?>' placeholder='0'//></td>
            <td><input type='number' name='avgcmhstf' value='<?php echo $avgcmhstf ?>' placeholder='0'//></td></tr>
            <tr  class='white'><td>Number of employees</td>
            <td><input type='number' name='noemgr' value='<?php echo $noemgr ?>' placeholder='0'//></td>
            <td><input type='number' name='noestf' value='<?php echo $noestf ?>' placeholder='0'//></td></tr>
            <tr class='submit'><td colspan='3'><input type='button' value='Calculate' onClick='calculateCoc()'/></td></tr>
            <tr class='grey'><td>Loss per year</td>
            <td><p id="lpymgr">$reslpymgr</p></td>
            <td><p id="lpystf">$reslpystf</p></td></tr>
            <tr class='calcrow'>
            <td><i>Grand total of losses per year</td>
            <td colspan='2'><p id="gtolpy">$resgtolpy</p></td>
            </tr>
            <tr><td colspan='3' >(*) Average for UK is 1.8/week for each staff (based on OPP/CIPD Research) </td></tr>
        </table>
    </form>
HEREDOC;

		return $out;
	}
}

$cocCalculatorPlugin = new CocCalculatorPlugin();

add_shortcode('coc-calculator', array($cocCalculatorPlugin, 'processShortcode'));
