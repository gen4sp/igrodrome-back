Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/mage-eventpress

Thank you for your contribution.