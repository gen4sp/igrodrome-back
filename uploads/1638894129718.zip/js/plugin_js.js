function calculateCoc() {
	var avgcmhmgr = document.cocForm.avgcmhmgr.value;
	var avgwhwmgr = document.cocForm.avgwhwmgr.value;
	var avgsalmgr = document.cocForm.avgsalmgr.value;
	var noemgr = document.cocForm.noemgr.value;
	avgsalmgr = avgsalmgr.replace(/,/g, "");

	var lpymgr = ( avgcmhmgr / (avgwhwmgr/100) ) / 100 * (avgsalmgr * noemgr);

	if (isNaN(lpymgr)) { 
		lpymgr = 0 ;
		document.getElementById("gtolpy").innerHTML = "£";
	} else {
		document.getElementById("lpymgr").innerHTML = lpymgr.toFixed(2);
		jQuery('#lpymgr').digits();
		jQuery('#lpymgr').html('£'+jQuery('#lpymgr').html());
	}

	var avgcmhstf = document.cocForm.avgcmhstf.value;
	var avgwhwstf = document.cocForm.avgwhwstf.value;
	var avgsalstf = document.cocForm.avgsalstf.value;
	var noestf = document.cocForm.noestf.value;	

	avgsalstf = avgsalstf.replace(/,/g, "");

	var lpystf = ( avgcmhstf / (avgwhwstf/100) ) / 100 * (avgsalstf * noestf);
	
	if (isNaN(lpystf)) {
		 lpystf = 0;
		 document.getElementById("lpystf").innerHTML =  "£";
	} else {
		document.getElementById("lpystf").innerHTML = lpystf.toFixed(2);
		jQuery('#lpystf').digits();
		jQuery('#lpystf').html('£'+jQuery('#lpystf').html());
	}
	document.getElementById("gtolpy").innerHTML = (lpystf+lpymgr).toFixed(2);
	jQuery('#gtolpy').digits();
	jQuery('#gtolpy').html('£'+jQuery('#gtolpy').html());
}

jQuery.fn.digits = function(){ 
    return this.each(function(){ 
        jQuery(this).text( jQuery(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
    })
}

jQuery(document).ready(function(){
	jQuery(".inputmask").inputmask({ alias: "currency"});
	
  });
