jQuery(document).on("change", ".mep_event_list_sec .etp", function () {
    calculateTotalQuantityTT(this);
});

jQuery(".mep_event_list_sec .etp").each(function () {
    calculateTotalQuantityTT(this);
});

function calculateTotalQuantityTT(obj) {
    var sum = 0;
    var total = 0;

    jQuery(obj).parents().eq(6).find('.ttyttl').html(jQuery(obj).val());
    var price = jQuery(obj).parents().eq(6).find('.price_jq');
    var count = jQuery(obj).parents().eq(6).find('.extra-qty-box');
    sum = (parseFloat(price.html().match(/-?(?:\d+(?:\.\d*)?|\.\d+)/)) * count.val());
    total = total + sum;

    jQuery(obj).parents().eq(6).find('.rowtotal').val(total);
    jQuery(obj).parents().eq(6).find('.usertotal').html(mp_event_wo_commerce_price_format(total));
}

function mp_event_wo_commerce_price_format(price) {
    let currency_position = jQuery('input[name="currency_position"]').val();
    let currency_symbol = jQuery('input[name="currency_symbol"]').val();
    let currency_decimal = jQuery('input[name="currency_decimal"]').val();
    let currency_thousands_separator = jQuery('input[name="currency_thousands_separator"]').val();
    let currency_number_of_decimal = jQuery('input[name="currency_number_of_decimal"]').val();
    let price_text = '';

    price = price.toFixed(currency_number_of_decimal);
// console.log('price= '+ price);
    let total_part = price.toString().split(".");
    total_part[0] = total_part[0].replace(/\B(?=(\d{3})+(?!\d))/g, currency_thousands_separator);
    price = total_part.join(currency_decimal);

    if (currency_position === 'right') {
        price_text = price + currency_symbol;
    } else if (currency_position === 'right_space') {
        price_text = price + '&nbsp;' + currency_symbol;
    } else if (currency_position === 'left') {
        price_text = currency_symbol + price;
    } else {
        price_text = currency_symbol + '&nbsp;' + price;
    }
    // console.log('price= '+ price_text);
    return price_text;
}

jQuery(document).ready(function($) {
    $('.qty_dec').on('click', function() {
        let target = $(this).siblings('input');
        let value = parseInt(target.val()) - 1;
        qtyPlace(target, value);
    });
    $('.qty_inc').on('click', function() {
        let target = $(this).siblings('input');
        let value = parseInt(target.val()) + 1;
        qtyPlace(target, value);
    });
    $('.mage_input_group input').on('keyup', function() {
        let target = $(this);
        let value = parseInt(target.val());
        if (target.val().length > 0) {
            qtyPlace(target, value);
        }

    });

    $('#mage_event_submit').on('submit', function() {
        if (mageErrorQty()) {
            return true;
        }
        return false;
    });
    $("select[name='option_qty[]']").on('blur', function() {
        mageErrorQty();
    });

    function qtyPlace(target, value) {
        let minSeat = parseInt(target.attr('min'));
        let maxSeat = parseInt(target.attr('max'));
        if (value < minSeat || isNaN(value)) {
            value = minSeat;
        }
        if (value > maxSeat) {
            value = maxSeat
        }
        target.val(value).change();
        mageErrorQty();

    }

    function mageErrorQty() {
        let total_ticket = 0;
        let target = $("[name='option_qty[]']");
        target.each(function(index) {
            total_ticket = total_ticket + parseInt($(this).val());
        });
        if (total_ticket > 0) {
            target.removeClass('mage_error');
            return true;
        }
        target.addClass('mage_error');
        return false;
    }
});

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.maxHeight){
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }
    });
}