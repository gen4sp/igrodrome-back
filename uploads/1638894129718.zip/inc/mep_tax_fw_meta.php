<?php
if (!defined('ABSPATH')) {
    die;
} // Cannot access pages directly.

/**
 * This will be used for Taxonomy Meta Box with the Brand New Mage Freamwork
 */