<?php
if (!defined('ABSPATH')) {
    die;
} // Cannot access pages directly.

/**
 * MagePeople Settings API
 * @version 1.0
 *
 */
if (!class_exists('MAGE_Events_Setting_Controls')) :
    class MAGE_Events_Setting_Controls
    {

        private $settings_api;

        function __construct()
        {
            $this->settings_api = new MAGE_Setting_API;

            add_action('admin_init', array($this, 'admin_init'));
            add_action('admin_menu', array($this, 'admin_menu'));
        }

        function admin_init()
        {

            //set the settings
            $this->settings_api->set_sections($this->get_settings_sections());
            $this->settings_api->set_fields($this->get_settings_fields());

            //initialize settings
            $this->settings_api->admin_init();
        }

        function admin_menu()
        {
            $event_label        = mep_get_option('mep_event_label', 'general_setting_sec', 'Events');
            //add_options_page( 'Event Settings', 'Event Settings', 'delete_posts', 'mep_event_settings_page', array($this, 'plugin_page') );

            add_submenu_page('edit.php?post_type=mep_events', __($event_label.' Settings', 'mage-eventpress'), __($event_label.' Settings', 'mage-eventpress'), 'manage_options', 'mep_event_settings_page', array($this, 'plugin_page'));
        }

        function get_settings_sections()
        {

            $sections = array(
                array(
                    'id' => 'general_setting_sec',
                    'title' => __('General Settings', 'mage-eventpress')
                ),
                array(
                    'id' => 'email_setting_sec',
                    'title' => __('Email Settings', 'mage-eventpress')
                ),
                array(
                    'id' => 'style_setting_sec',
                    'title' => __('Style Settings', 'mage-eventpress')
                ),
                array(
                    'id' => 'label_setting_sec',
                    'title' => __('Translation Settings', 'mage-eventpress')
                ),
                array(
                    'id' => 'carousel_setting_sec',
                    'title' => __('Carousel Settings', 'mage-eventpress')
                )
            );



            return apply_filters('mep_settings_sec_reg', $sections);
        }

        /**
         * Returns all the settings fields
         *
         * @return array settings fields
         */
        function get_settings_fields()
        {
            $settings_fields = array(
                'general_setting_sec' => apply_filters('mep_settings_general_arr',array(
                    array(
                        'name' => 'mep_disable_block_editor',
                        'label' => __('Disable Block/Gutenberg Editor', 'mage-eventpress'),
                        'desc' => __('If you want to disable WordPress new Block/Gutenberg editor for event please select Yes', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),                   
                    array(
                        'name' => 'mep_multi_lang_plugin',
                        'label' => __('Your Multilanguage Plugin', 'mage-eventpress'),
                        'desc' => __('If you are using a multi language plugin, Please select the plugin name from the below list', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'none',
                        'options' =>  array(
                            'none'      => 'None',
                            'polylang'  => 'Polylang',
                            'wpml'      => 'WPML'
                        )
                    ),                   
                    array(
                        'name' => 'mep_event_label',
                        'label' => __('Event Label', 'mage-eventpress'),
                        'desc' => __('If you want to change the event label in the dashboard menu you can change here', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Events'
                    ),
                   
                    array(
                        'name' => 'mep_event_slug',
                        'label' => __('Event Slug', 'mage-eventpress'),
                        'desc' => __('Please enter the slug name you want. Remember after change this slug you need to flush permalink, Just go to Settings->Permalink hit the Save Settings button', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'events'
                    ),
                   
                    array(
                        'name' => 'mep_event_icon',
                        'label' => __('Event Icon', 'mage-eventpress'),
                        'desc' => __('If you want to change the event icon in the dashboard menu you can change from here, Dashboard icon only support dashicon, So please go to <a href=https://developer.wordpress.org/resource/dashicons/#calendar-alt target=_blank>Dash Icon</a> and copy your icon code and paste here', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'dashicons-calendar-alt'
                    ),
                   

                    array(
                        'name' => 'mep_event_cat_label',
                        'label' => __('Event category Label', 'mage-eventpress'),
                        'desc' => __('If you want to change the event category label in the dashboard menu you can change here', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Category'
                    ),
                    array(
                        'name' => 'mep_event_cat_slug',
                        'label' => __('Event Category Slug', 'mage-eventpress'),
                        'desc' => __('Please enter the slug name you want for event category. Remember after change this slug you need to flush permalink, Just go to Settings->Permalink hit the Save Settings button', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'mep_cat'
                    ),
                    array(
                        'name' => 'mep_event_org_label',
                        'label' => __('Event Organizer Label', 'mage-eventpress'),
                        'desc' => __('If you want to change the event category label in the dashboard menu you can change here', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Organizer'
                    ),
                    array(
                        'name' => 'mep_event_org_slug',
                        'label' => __('Event Organizer Slug', 'mage-eventpress'),
                        'desc' => __('Please enter the slug name you want for event category. Remember after change this slug you need to flush permalink, Just go to Settings->Permalink hit the Save Settings button', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'mep_org'
                    ),

                   
                    array(
                        'name' => 'mep_google_map_type',
                        'label' => __('Google Map Type?', 'mage-eventpress'),
                        'desc' => __('Please select the map type you  want to show in fronntend, Note it: Iframe Not always show the accurate location where API enable map has drag & drop feature so you can drag the point to accurate location.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            '' => 'Please Select a Map Type',
                            'api' => 'API',
                            'iframe' => 'Iframe'
                        )
                    ),
                    array(
                        'name' => 'google-map-api',
                        'label' => __('Google Map API Key', 'mage-eventpress'),
                        'desc' => __('Enter Your Google Map API key. <a href=https://developers.google.com/maps/documentation/javascript/get-api-key target=_blank>Get KEY</a>. Note: You must enter billing address and information into google map api account to work perfectly the google map in website.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_enable_speaker_list',
                        'label' => __('Enable Speaker List?', 'mage-eventpress'),
                        'desc' => __('If you want to enable speaker list, Please select Yes by default its disable', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_show_product_cat_in_event',
                        'label' => __('Show Product Category in Event?', 'mage-eventpress'),
                        'desc' => __('Want to show Product Category in Event Edit Page? If you want set product category based coupon code you need to assign event into Product category, Please set yes only when you need it', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_global_single_template',
                        'label' => __('Event Details Template', 'mage-eventpress'),
                        'desc' => __('Event Details Template', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  mep_event_template_name()
                    ),
                    array(
                        'name' => 'mep_event_price_show',
                        'label' => __('Show Event Price in List?', 'mage-eventpress'),
                        'desc' => __('Please select if you want to show event price in the list Yes/No', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_date_list_in_event_listing',
                        'label' => __('Show Multi Date List in Event listing Page?', 'mage-eventpress'),
                        'desc' => __('Please select if you want to show the full date list for multi date event in the event listing page', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_product_type',
                        'label' => __('Enable Shipping Method on event?', 'mage-eventpress'),
                        'desc' => __('Please Select The event product type which is using in WooCommerce, By default its virtual. If you change this type you need to re-save all the event again.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'yes' => 'No',
                            'no' => 'Yes'
                        )
                    ),
                    array(
                        'name' => 'event-price-label',
                        'label' => __('Event Price Label', 'mage-eventpress'),
                        'desc' => __('Enter The text which you want to show as price label, Its only displayed if Show Event price value is YES above. ', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Price Starts from:'
                    ),
                    array(
                        'name' => 'mep_event_time_format',
                        'label' => __('Event Time Format', 'mage-eventpress'),
                        'desc' => __('Please select what format time you want to display in event fronntend.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'wtss',
                        'options' =>  array(
                            'wtss' => 'WordPress TimeStamp Settings'
                        )
                    ),
                    array(
                        'name' => 'mep_event_direct_checkout',
                        'label' => __('Redirect Checkout after Booking?', 'mage-eventpress'),
                        'desc' => __('If you want to go direct checkout page after booking an event please enable/disable this.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'yes' => 'Enable',
                            'no' => 'Disable'
                        )
                    ),
                    array(
                        'name' => 'mep_event_expire_on_datetimes',
                        'label' => __('When will event expire', 'mage-eventpress'),
                        'desc' => __('Please select when event will expire, On event start time or event endtime', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'mep_event_start_date',
                        'options' =>  array(
                            'event_start_datetime' => 'Event Start Time',
                            'event_expire_datetime' => 'Event End Time'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_organizer_list',
                        'label' => __('Hide Organizer Section from list ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide organizer section from list.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_location_list',
                        'label' => __('Hide Location Section from list ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide location section from list.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_time_list',
                        'label' => __('Hide Full Time Section from list ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide time section from list.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_end_time_list',
                        'label' => __('Hide Only End Time Section from list ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide Only End Time  section from list.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_date_from_details',
                        'label' => __('Hide Event Date Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide time section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_time_from_details',
                        'label' => __('Hide Event Time Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide time section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_location_from_details',
                        'label' => __('Hide Event Location Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide location section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_total_seat_from_details',
                        'label' => __('Hide Event Total Seats Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to hide Total Seats Section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_org_from_details',
                        'label' => __('Hide "Org By" Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to Event by Section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_address_from_details',
                        'label' => __('Hide Event Address Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to Event Address Section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_event_schedule_details',
                        'label' => __('Hide Event Schedule Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to Event Schedule Section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_share_this_details',
                        'label' => __('Hide Event Share this Section from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to Event Share this Section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_event_hide_calendar_details',
                        'label' => __('Hide Add Calendar Button from Details page ?', 'mage-eventpress'),
                        'desc' => __('Select yes to Event google map Section from details.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_hide_location_from_order_page',
                        'label' => __('Hide Location From Order Details & Email Section?', 'mage-eventpress'),
                        'desc' => __('If you want to hide Location from order details section in the tankyou page & from the confirmation email body, Please select Yes. By default is: No.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_hide_date_from_order_page',
                        'label' => __('Hide Date From Order Details & Email Section?', 'mage-eventpress'),
                        'desc' => __('If you want to hide Date from order details section in the tankyou page & from the confirmation email body, Please select Yes. By default is: No.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),
	                array(
		                'name'    => 'mep_hide_event_hover_btn',
		                'label'   => __( 'Hide / Visible Event Hover Book Now Button ?', 'mage-eventpress' ),
		                'desc'    => __( 'If you want to Hide / Visible Event Hover Book Now Button , Please select Yes. By default is: No.', 'mage-eventpress' ),
		                'type'    => 'select',
		                'default' => 'no',
		                'options' => array(
			                'yes' => 'Yes',
			                'no'  => 'No'
		                )
	                ),
	                array(
		                'name'    => 'mep_hide_event_hover_btn_text',
		                'label'   => __( 'Event Hover Book Now Button Text ?', 'mage-eventpress' ),
		                'desc'    => __( 'Pleaase Type Event Hover Book Now Button Text . OtherWise It will be Book Now.', 'mage-eventpress' ),
		                'type'    => 'text',
		                'default' => 'Book Now',
		                'placeholder'=>'Book Now'
                    ),
	                array(
		                'name'    => 'mep_show_zero_as_free',
		                'label'   => __( 'Show 0 Price as Free ?', 'mage-eventpress' ),
		                'desc'    => __( 'If you want to show 0 Price as Free , Please select Yes.', 'mage-eventpress' ),
		                'type'    => 'select',
		                'default' => 'yes',
		                'options' => array(
			                'yes' => 'Yes',
			                'no'  => 'No'
		                )
	                ),                    
	                array(
		                'name'    => 'mep_ticket_expire_time',
		                'label'   => __( 'Event Ticket Expire before minutes', 'mage-eventpress' ),
		                'desc'    => __( 'Please enter the minute that you want attendee can not book/register the ticket before start of the event', 'mage-eventpress' ),
		                'type'    => 'text',
		                'default' => '0',
		                'placeholder'=>'15'
                    ),






                )
                ),

                'email_setting_sec' => apply_filters('mep_settings_email_arr',array(
                    array(
                        'name' => 'mep_email_sending_order_status',
                        'label' => __( 'Email Sent on order status', 'mage-eventpress' ),
                        'desc' => __( 'Please Select when and which order status event confirmation email will send to customer', 'mage-eventpress' ),
                        'type' => 'multicheck',
                        'default' => array( 'completed' => 'completed' ),
                        'options' => array(
                            'processing' => 'Processing',
                            'completed' => 'Completed'
                        )
                    ),        
                                           
                    array(
                        'name' => 'mep_email_form_name',
                        'label' => __('Email From Name', 'mage-eventpress'),
                        'desc' => __('Email From Name', 'mage-eventpress'),
                        'default' => '',
                        'type' => 'text'
                    ),
                    array(
                        'name' => 'mep_email_form_email',
                        'label' => __('From Email', 'mage-eventpress'),
                        'desc' => __('From Email', 'mage-eventpress'),
                        'type' => 'text'
                    ),
                    array(
                        'name' => 'mep_email_subject',
                        'label' => __('Email Subject', 'mage-eventpress'),
                        'desc' => __('Email Subject', 'mage-eventpress'),
                        'type' => 'text'
                    ),
                    array(
                        'name' => 'mep_confirmation_email_text',
                        'label' => __('Confirmation Email Text', 'mage-eventpress'),
                        'desc' => __('Confirmation Email Text <b>Usable Dynamic tags:</b><br/> Attendee
                        Name:<b>{name}</b><br/>
                        Event Name: <b>{event}</b><br/>
                        Ticket Type: <b>{ticket_type}</b><br/>
                        Event Date: <b>{event_date}</b><br/>
                        Start Time: <b>{event_time}</b><br/>
                        Full DateTime: <b>{event_datetime}</b>', 'mage-eventpress'),
                        'type' => 'wysiwyg',
                        'default' => '',
                    ),
                )
                ),

                'label_setting_sec' =>  apply_filters('mep_translation_string_arr',array(
	                array(
		                'name'    => 'mep_free_price_text',
		                'label'   => __( 'Free ?', 'mage-eventpress' ),
		                'desc'    => __( 'Pleaase Type the text which you want to as 0 Price.', 'mage-eventpress' ),
		                'type'    => 'text',
		                'default' => 'Free',
		                'placeholder'=>'Free'
                    ),                    
                    array(
                        'name' => 'mep_event_ticket_type_text',
                        'label' => __('Ticket Type Table Label', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as ticket type table in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Ticket Type:'
                    ),
                    array(
                        'name' => 'mep_event_extra_service_text',
                        'label' => __('Extra Service Table Label', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as extra service table in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Extra Service:'
                    ),
                    array(
                        'name' => 'mep_cart_btn_text',
                        'label' => __('Cart Button Label', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display in Cart button in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Register This Event'
                    ),
                    array(
                        'name' => 'mep_calender_btn_text',
                        'label' => __('Add Calendar Button Label', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display in Add you calender in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'ADD TO YOUR CALENDAR'
                    ),
                    array(
                        'name' => 'mep_share_text',
                        'label' => __('Social Share Label', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as share button title in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Share This Event'
                    ),
                    array(
                        'name' => 'mep_organized_by_text',
                        'label' => __('Organized By:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Organized By in event list page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_location_text',
                        'label' => __('Location:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Location in event list page & Order Confirmation Page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_time_text',
                        'label' => __('Time:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Time in event list page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_event_location_text',
                        'label' => __('Event Location:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Event Location in event list page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_event_date_text',
                        'label' => __('Event Date:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Event Date in event list page & Order Confirmation Page', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_event_time_text',
                        'label' => __('Event Time:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Event Time in event list page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),

                    array(
                        'name' => 'mep_by_text',
                        'label' => __('By:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as By in event list page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_total_seat_text',
                        'label' => __('Total Seats:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Total Seats in event list page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_register_now_text',
                        'label' => __('Register Now:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Register Now in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_quantity_text',
                        'label' => __('Quantity:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Quantity in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_name_text',
                        'label' => __('Name:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Name in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Name:'
                    ),
                    array(
                        'name' => 'mep_price_text',
                        'label' => __('Price:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Price in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Price:'
                    ),
                    array(
                        'name' => 'mep_event_schedule_text',
                        'label' => __('Event Schedule Details', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Event Schedule Details in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Event Schedule Details'
                    ),
                    array(
                        'name' => 'mep_total_text',
                        'label' => __('Total:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Total in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_ticket_qty_text',
                        'label' => __('Ticket Qty', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Ticket Qty in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_per_ticket_price_text',
                        'label' => __('Per Ticket Price:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as per Ticket price in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),

                    array(
                        'name' => 'mep_no_ticket_selected_text',
                        'label' => __('No Ticket Selected!', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as No Ticket Selected in event details page.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),

                    array(
                        'name' => 'mep_no_seat_available_text',
                        'label' => __('No Seat Available', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as No Seat Available.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),

                    array(
                        'name' => 'mep_not_available_text',
                        'label' => __('Not Available', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Not Available.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),

                    array(
                        'name' => 'mep_event_expired_text',
                        'label' => __('Event Expired', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Event Expired.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),

                    array(
                        'name' => 'mep_ticket_text',
                        'label' => __('Ticket', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Ticket.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_left_text',
                        'label' => __('Left', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Left.', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_attendee_info_text',
                        'label' => __('Attendee info:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display as Attendee info:', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => ''
                    ),
                    array(
                        'name' => 'mep_select_ticket_error_message',
                        'label' => __('Select Ticket Error Message:', 'mage-eventpress'),
                        'desc' => __('Enter the text which you want to display when no ticket selected popup display:', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Please select atleast one(1) ticket Quantity !'
                    ),
                    array(
                        'name' => 'mep_event_virtual_label',
                        'label' => __('Virtual Event Rebon', 'mage-eventpress'),
                        'desc' => __('Enter Text For Virtual Event Rebon', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Virtual Event'
                    ),
                    array(
                        'name' => 'mep_event_multidate_ribon_text',
                        'label' => __('Multi Date Event Rebon', 'mage-eventpress'),
                        'desc' => __('Enter Text For Multi Date Event Rebon', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Multi Date Event'
                    ),
                    array(
                        'name' => 'mep_event_view_more_date_btn_text',
                        'label' => __('View More Date Button', 'mage-eventpress'),
                        'desc' => __('Enter Text For View More Date button', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'View More Date'
                    ),
                    array(
                        'name' => 'mep_event_hide_date_list_btn_text',
                        'label' => __('Hide Date Lists Button', 'mage-eventpress'),
                        'desc' => __('Enter Text For Hide Date Lists button', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Hide Date Lists'
                    ),
                    array(
                        'name' => 'mep_event_recurring_ribon_text',
                        'label' => __('Recurring Ribon Text', 'mage-eventpress'),
                        'desc' => __('Recurring Event ribon text', 'mage-eventpress'),
                        'type' => 'text',
                        'default' => 'Recurring Event'
                    )
                   
                )),

                'style_setting_sec' => apply_filters('mep_settings_styling_arr',array(
                    array(
                        'name' => 'mep_base_color',
                        'label' => __('Base Color', 'mage-eventpress'),
                        'desc' => __('Select a Basic Color, It will chanage the icon background color, border color', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_title_bg_color',
                        'label' => __('Label Background Color', 'mage-eventpress'),
                        'desc' => __('Select a Color Label Background', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_title_text_color',
                        'label' => __('Label Text Color', 'mage-eventpress'),
                        'desc' => __('Select a Color Label Text', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_cart_btn_bg_color',
                        'label' => __('Cart Button Background Color', 'mage-eventpress'),
                        'desc' => __('Select a color for Cart Button Background', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_cart_btn_text_color',
                        'label' => __('Cart Button Text Color', 'mage-eventpress'),
                        'desc' => __('Select a color for Cart Button Text', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_calender_btn_bg_color',
                        'label' => __('Calender Button Background Color', 'mage-eventpress'),
                        'desc' => __('Select a color for Calender Button Background', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_calender_btn_text_color',
                        'label' => __('Calender Button Text Color', 'mage-eventpress'),
                        'desc' => __('Select a color for Calender Button Text', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_faq_title_bg_color',
                        'label' => __('FAQ Title Background Color', 'mage-eventpress'),
                        'desc' => __('Select a color for FAQ title Background', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                    array(
                        'name' => 'mep_faq_title_text_color',
                        'label' => __('FAQ Title Text Color', 'mage-eventpress'),
                        'desc' => __('Select a color for FAQ Title Text', 'mage-eventpress'),
                        'type' => 'color',
                    ),
                )
                ),

                'carousel_setting_sec' => apply_filters('mep_settings_carousel_arr',array(

                    array(
                        'name' => 'mep_load_carousal_from_theme',
                        'label' => __('Load owl Carousel From Theme', 'mage-eventpress'),
                        'desc' => __('If your theme Carousel stop working or in your theme already loaded the OWL Carousel Lib, then you can set this yes?', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'no',
                        'options' =>  array(
                            'yes' => 'Yes',
                            'no' => 'No'
                        )
                    ),

                    array(
                        'name' => 'mep_autoplay_carousal',
                        'label' => __('Auto Play', 'mage-eventpress'),
                        'desc' => __('Please select Carousel will auto play or not.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'true' => 'Yes',
                            'false' => 'No'
                        )
                    ),
                    array(
                        'name' => 'mep_loop_carousal',
                        'label' => __('Infinite Loop', 'mage-eventpress'),
                        'desc' => __('Please select Carousel will Infinite Loop or not.', 'mage-eventpress'),
                        'type' => 'select',
                        'default' => 'yes',
                        'options' =>  array(
                            'true' => 'Yes',
                            'false' => 'No'
                        )
                        ),
                        array(
                            'name' => 'mep_speed_carousal',
                            'label' => __('Carousel Auto Play Speed', 'mage-eventpress'),
                            'desc' => __('Please Enter Carousel Auto Play Speed, Default 5000', 'mage-eventpress'),
                            'type' => 'text',
                            'default' => '5000'
                        ),                        






                )

                )
            );

            return apply_filters('mep_settings_sec_fields', $settings_fields);
        }

        function plugin_page()
        {
            echo '<div class="wrap mage_settings_panel_wrap">';

            $this->settings_api->show_navigation();
            $this->settings_api->show_forms();

            echo '</div>';
        }

        /**
         * Get all the pages
         *
         * @return array page names with key value pairs
         */
        function get_pages()
        {
            $pages = get_pages();
            $pages_options = array();
            if ($pages) {
                foreach ($pages as $page) {
                    $pages_options[$page->ID] = $page->post_title;
                }
            }

            return $pages_options;
        }
    }
endif;

$settings = new MAGE_Events_Setting_Controls();


function mep_get_option($option, $section, $default = '')
{
    $options = get_option($section);

    if (isset($options[$option])) {
        return $options[$option];
    }

    return $default;
}



add_action('wsa_form_bottom_mep_settings_licensing','mep_licensing_page',5);
function mep_licensing_page($form){
?>
<div class='mep-licensing-page'>
<h3>Woocommerce Event Manager Licensing</h3>
<p>Thanks you for using our Woocommerce Event Manager plugin. This plugin is free and no license is required. We have some Additional addon to enhace feature of this plugin functionality. If you have any addon you need to enter a valid license for that plugin below.  </p>

<div class="mep_licensae_info"></div>
<table class='wp-list-table widefat striped posts mep-licensing-table'>
    <thead>
        <tr>
            <th>Plugin Name</th>
            <th width=10%>Order No</th>
            <th width=15%>Expire on</th>
            <th width=30%>License Key</th>
            <th width=10%>Status</th>
            <th width=10%>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php do_action('mep_license_page_addon_list'); ?>
    </tbody>
</table>
</div>
<?php
}

add_action('wsa_form_bottom_mep_settings_templates','mep_settings_template_page',5);
function mep_settings_template_page($form){
?>
<div class='mep-licensing-page'>
<h3>Ready Templates For Event Details Page.</h3>


<div class="mep_licensae_info"></div>


<div class="mep-template-lists">


<?php
$url        = 'https://vaincode.com/update/template/template.json';
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HEADER, false);
$data = curl_exec($curl);
curl_close($curl);
$obj = json_decode($data, true);

// print_r($data);

if(is_array($obj) && sizeof($obj) > 0){
echo '<div class="mep_ready_template_sec"><ul class="mep_ready_template_list">';
foreach ($obj as $list) {
    $name       = $list['name'];
    $banner     = $list['banner'];
    $url        = $list['url'];
    $type       = $list['type'];
    $editor     = $list['editor'];
    $preview     = $list['preview'];
    $name_slug  = sanitize_title($name);
    $count_import = get_option('mep_import_template_'.$name_slug) ? get_option('mep_import_template_'.$name_slug) : 0;
echo '<li>';
	echo '<div class="template-thumb"><img src='.$banner.'></div>';
    echo '<h3>'.$name.'</h3>';

if($count_import > 0){
    echo '<p class="mep-template-import-count"> Imported '.$count_import.' times</p>';
}

    if ( did_action( 'elementor/loaded' ) && $editor == 'elm' ) {    
        echo "<button class='import_template' data-file='$url' data-name='$name' data-editor='$editor' data-type='$type'>Import</button>";
    }else{
        echo "<p class='mep-msg mep-msg-warning'>Elementor Not Installed</p>";
    }
    echo "<a href='$preview' class='preview-btn btn' target='_blank'>Preview</a>";
echo '</li>';
}
echo '</ul></div>';
}
?>
</div>

<script>
                (function($) {
                    'use strict';               
                    jQuery('.import_template').on('click', function() {
                        if (confirm('Are You Sure to Import this Template ? \n\n 1. Ok : To Import . \n 2. Cancel : To Cancel .')) {
                            var file            = jQuery(this).data('file');
                            var type            = jQuery(this).data('type');
                            var editor          = jQuery(this).data('editor');
                            var name            = jQuery(this).data('name');
                            jQuery.ajax({
                                type    : 'POST',
                                url     : ajaxurl,                                
                                data    : {
                                    "action"                : "mep_import_ajax_template",
                                    "nonce"                 : '<?php echo wp_create_nonce('mep-ajax-import-template-nonce'); ?>',    
                                    "file"                  : file,
                                    "editor"                : editor,
                                    "name"                  : name,
                                    "type"                  : type                                   
                                },
                                beforeSend: function() {
                                    jQuery('.mep_licensae_info').html('<h5 class="mep-msg mep-msg-process">Please wait.. Importing Template..</h5>');
                                },
                                success: function(data) {
                                    jQuery('.mep_licensae_info').html(data);
                                    window.location.reload();
                                }
                            });
                        } else {
                            return false;
                        }
                        return false;
                    });
                })(jQuery);
            </script>


</div>
<?php
}