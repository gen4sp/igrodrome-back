<?php
if (!defined('ABSPATH')) {
    die;
} // Cannot access pages directly.

add_action('mep_event_ticket_types', 'mep_ev_ticket_type',10,3);
if (!function_exists('mep_ev_ticket_type')) {
    function mep_ev_ticket_type($post_id,$ticket_type_label,$select_date_label)
    {
        global $post, $product, $event_meta;
        $count = 1;
        ob_start();
        $mep_available_seat     = array_key_exists('mep_available_seat', $event_meta) ? $event_meta['mep_available_seat'][0] : 'on';
        $mep_event_ticket_type  = get_post_meta($post_id, 'mep_event_ticket_type', true) ? get_post_meta($post_id, 'mep_event_ticket_type', true) : array();

        if ($mep_event_ticket_type) {
?>
            <?php echo "<h3 class='ex-sec-title mep_ticket_type_title'>" .$ticket_type_label. "</h3>"; ?>
            <table id='mep_event_ticket_type_table'>
                <?php do_action('mep_event_ticket_type_loop_list', $post_id); ?>
            </table>
        <?php
        }

        $content = ob_get_clean();
        echo apply_filters('mage_event_ticket_type_list', $content, $post_id, $event_meta,$ticket_type_label,$select_date_label);
        ?>
<?php
    }
}
