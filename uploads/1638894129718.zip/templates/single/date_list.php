<li>
    <span class="mep-more-date"><i class="fa fa-calendar"></i>     
    <span class='mep_date_scdl_start_datetime'> <?php echo get_mep_datetime($start_datetime, 'date-text'); ?>  <?php echo get_mep_datetime($start_datetime, 'time'); ?></span>              
    <?php if($end_date_display_status == 'yes'){?> <span class='mep_date_scdl_end_datetime'> <?php echo ' <span class="mep_date_scdl_separator"> - </span> '; if ($start_date != $end_date) {  get_mep_datetime($end_datetime, 'date-text'); } echo  ' '.get_mep_datetime($end_datetime, 'time'); echo '</span>'; } ?>        
    </span>
</li>