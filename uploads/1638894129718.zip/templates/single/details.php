<?php
echo apply_filters('mep_event_details_content', $content, get_the_id());